<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/app/controllers/AuthController.php';
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/app/controllers/AuthController.php';

$auth = new AuthController();
$auth->logout();
$auth->logout();
$auth->logout();
